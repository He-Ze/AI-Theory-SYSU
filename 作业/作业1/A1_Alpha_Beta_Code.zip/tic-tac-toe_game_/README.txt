python *.py 开始游戏

